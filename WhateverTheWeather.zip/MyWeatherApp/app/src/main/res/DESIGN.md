The app begins by displaying the weather. We decided that this was a good start page for the user.
This is done in the "MainActivity" class (app/java/com.androstock.myweatherapp).
In this class, we initialize the varibale corresponding to what is being displayed on the home page.
In order to retrieve the weather data, we used a weather API key which provided us with JSON data.
In the "Function" class, we retrieve the specifics of this data and modify it's format.
This information is then passed into "MainActivity", allowing our app to display reader-friendly values.
In order to link style/format to the data needing to be displayed, we used the "activity_main.xml" file (app/res/layout).
In this file, we adjusted the view of the home page and the methods in which we were displaying the values to make it visually appealing.
For example: Backgroud color, images, icons, sizes, fonts etc...


Next, we added the female clothing feature.
In order to navigate from the home page to the feminine clothing page, we used a floating action button which
is displayed on the bottom right of the home page.
When a user clicks on the button, they are re-directed to the new page, where the "FemaleClothingActivity" class takes over.
In this class, we set up three text values: a title, gender, and a message (which changes depending on the weather)
In addition to the text values, we also included visual aids as images which can all be down in the "drawable folder" (app/res/drawable).
We placed all of these images into a list in this class, therefore assigning every image an index.
Then, using the weather data retrieved through the JSON functionality with the help of the "Function" class,
we assigned these indexes (images) to various weather conditions.
We included around 8 different conditions corresponding to various temperatures and precipitation.
We connect this class to the main through the previously mentioned floating action button, which also includes an icon indicating female clothing.
To adjust the layout and overall display, we used many xml calls to taylor the design of our app to our personal aesthetic.
These adjustments can be found in the "activity_female_clothing.xml" file (app/res/layout).


This same outline was followed to create the male clothing page, changing only a few clothign preferences and the background color.


In order to retrieve the user's location, we used the "Async" method called in "Function".
For now, we were only able to manually input latitude and longitude, which can be changed but only through the code and this function.
This is because we ran into many many complications trying to retrieve the user's immediate current location (we needed many permission calls and our version of Android Studio was incompetent for this).
Currently, the location is set to Cambridge, MA. It can be changed by simply inputing new Lat and Lon coordinated into the "MainActivity" class on line 55.


We hope you enjoy!!!
-Dina, Maria, Kiva (DMK.Inc).

Youtube Link: https://m.youtube.com/watch?v=WPUp7tRk9i0



