package com.androstock.myweatherapp;

import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class FemaleClothingActivity extends AppCompatActivity {

    TextView title, gender, test, message;
    ImageView appImageView1, appImageView2;
    Drawable drawable;
    Random random;
    Drawable [] drawables = null;
    Typeface font;

    // constructor
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_female_clothing);
        getSupportActionBar().hide();

        // initializes variables in the xml file
        title = (TextView)findViewById(R.id.title);
        gender = (TextView) findViewById(R.id.gender);
        message = (TextView) findViewById(R.id.message);

        // retrieves the font
        font = Typeface.createFromAsset(getApplicationContext().getAssets(), "fonts/weathericons-regular-webfont.ttf");

        // sets the text of the title words
        gender.setText("Feeling Feminine?");
        title.setText("TODAY WEAR");

        // initializes the images of the clothing to wear
        appImageView1 = (ImageView) findViewById(R.id.imageView1);
        appImageView2 = (ImageView) findViewById(R.id.imageView2);

        // list of images to retrieve
        // the images change based on the weather
        drawables = new Drawable[] {
                getResources().getDrawable(R.drawable.dress), //0
                getResources().getDrawable(R.drawable.tshirt), //1
                getResources().getDrawable(R.drawable.cardigan), //2
                getResources().getDrawable(R.drawable.female_shorts), //3
                getResources().getDrawable(R.drawable.gloves), //4
                getResources().getDrawable(R.drawable.jacket), //5
                getResources().getDrawable(R.drawable.joggers), //6
                getResources().getDrawable(R.drawable.light_jacket), //7
                getResources().getDrawable(R.drawable.long_sleeves), //8
                getResources().getDrawable(R.drawable.male_jeans), //9
                getResources().getDrawable(R.drawable.tshirt), //10
                getResources().getDrawable(R.drawable.male_shorts), //11
                getResources().getDrawable(R.drawable.male_tank), //12
                getResources().getDrawable(R.drawable.poncho), //13
                getResources().getDrawable(R.drawable.pullover), //14
                getResources().getDrawable(R.drawable.sun_hat), //15
                getResources().getDrawable(R.drawable.sweatshirt), //16
                getResources().getDrawable(R.drawable.swimsuit), //17
                getResources().getDrawable(R.drawable.tank), //18
                getResources().getDrawable(R.drawable.tshirt), //19
                getResources().getDrawable(R.drawable.turtle_neck), //20
                getResources().getDrawable(R.drawable.umbrella), //21
                getResources().getDrawable(R.drawable.winter_hat), //22
        };

        Function.placeIdTask asyncTask =new Function.placeIdTask(new Function.AsyncResponse() {
            public void processFinish(String weather_city, String weather_description, String weather_temperature, String weather_humidity, String weather_pressure, String weather_updatedOn, String weather_iconText, String sun_rise) {

                // gets the temperature
                double temp = Double.parseDouble(weather_temperature.substring(0, weather_temperature.length() - 1));

                // gets whether it is raining or snowing
                String pre = weather_description;

                // a variety of 'if' statements checking for different weather conditions and
                // changing what one wears based on those conditions
                if (temp < 32)
                {
                    appImageView1.setImageDrawable(drawables[22]);
                    appImageView2.setImageDrawable(drawables[5]);
                    message.setText("Brrrrrrr!");
                    if (pre.equals("snow") || pre.equals("SNOW"))
                    {
                        message.setText("Don't get stuck in the snow, stay in and drink a hot bev.");
                    }

                }
                if (temp > 32 && temp < 45)
                {
                    appImageView1.setImageDrawable(drawables[20]);
                    appImageView2.setImageDrawable(drawables[9]);
                    message.setText("It's chilly today, wear warm layers.");
                }
                if (temp >= 45 && temp < 50)
                {
                    appImageView1.setImageDrawable(drawables[7]);
                    appImageView2.setImageDrawable(drawables[9]);
                    message.setText("Make sure to mix in a sweater with your light jacket.");

                }
                if (temp >= 50 && temp < 60)
                {
                    appImageView1.setImageDrawable(drawables[8]);
                    appImageView2.setImageDrawable(drawables[9]);
                    message.setText("Nice day, maybe throw in a vest?");
                }
                if (temp >= 60 && temp < 70)
                {
                    appImageView1.setImageDrawable(drawables[1]);
                    appImageView2.setImageDrawable(drawables[9]);
                    message.setText("It's warm-ish, a t-shirt will be just fine.");
                }
                if (temp >= 70 && temp < 80)
                {
                    appImageView1.setImageDrawable(drawables[1]);
                    appImageView2.setImageDrawable(drawables[3]);
                    message.setText("It's so nice today! Enjoy :)");
                }
                if (temp >= 80 && temp < 90)
                {
                    appImageView1.setImageDrawable(drawables[15]);
                    appImageView2.setImageDrawable(drawables[0]);
                    message.setText("Hot hot hot! Just like you will be in this dress!");
                }
                if (temp >= 90)
                {
                    appImageView1.setImageDrawable(drawables[15]);
                    appImageView2.setImageDrawable(drawables[17]);
                    message.setText("Skip work, and hit the beach, you earned it ;)");
                }
                if (pre.equals("rain") || pre.equals("RAIN"))
                {
                    appImageView1.setImageDrawable(drawables[13]);
                    appImageView2.setImageDrawable(drawables[21]);
                    message.setText("It's raining, don't forget your umbrella & a poncho!");
                }
            }

        });
        asyncTask.execute("42.377196", "-71.116647");



    }


}
